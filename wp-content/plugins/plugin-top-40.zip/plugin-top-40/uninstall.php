<?php

if (!defined('WP_UNINSTAL_PLUGIN')) {
    die();
}